Integrantes: 
Rodríguez Abreu, José Ricardo.
Zamora Gutiérrez Víctor.

Instrucciones de uso:
Para ejecutar el programa después de compilarlo se debe iniciar el cifrado/descifrado del texto de la siguiente manera:
Se debe invocar el programa de la siguiente manera java Main <cifra/descifra> <palabra clave> <archivo de entrada> <archivo de salida>
Donde en <cifra/descifra> se debe colocar la operación que se desea obtener.
