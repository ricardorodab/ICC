Generar el codigo con netbeans.
Correr desde terminal de la siguiente manera:
Si se desea cifrar se debe escribir:
java -jar dist/Criptografia.jar <archivo a cifrar con terminacion .png>
Si se desea descifear se debe escribir:
java -jar dist/Criptografia.jar <archivo 1 a descifrar con terminacion .png>  <archivo 2 a descifrar con terminacion .png>.

Autores: 
Rodríguez Abreu José Ricardo.
Zamora Gutiérrez Víctor.
