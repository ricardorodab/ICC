Este programa tiene como finalidad generar 2 fractales: El triángulo de Sierpinski y la curva de Koch.
Se debe compilar el programa usando java o ant. 

Autores del programa:
Rodríguez Abreu, José Ricardo.
Víctor Zamora Gutiérrez.
