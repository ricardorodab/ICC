Autor del programa: Rodríguez Abreu, José Ricardo.
Fecha de actualizción: Octubre 12, del 2013. Versión 3.0
Fecha de creación: Octubre 6, del 2013.
Este programa lee un archivo de texto y organiza los datos.
Para ejecutar este programa se debe tener un archivo de texto donde se encuentren las tarjetas a imprimir y ejecutarlo de la forma:
"java Main <archivo>".
