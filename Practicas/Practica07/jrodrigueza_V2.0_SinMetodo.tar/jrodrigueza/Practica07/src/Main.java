/*
 * Main.java
 * Versión 2.0
 * Facultad de Ciencias,
 * Universidad Nacional Autónoma de México, México.
 * José Ricardo Rodríguez Abreu
 * 
 * Este programa toma una archivo e imprime en pantalla las tarjetas 
 * con un respectivo orden y colocando el indicador antes de cada dato
 *
 */

import tarjeta.*; //Se importan las clases creadas con anterioridad.
import java.util.LinkedList;
import java.util.Scanner;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 *@author Jose Ricardo Rodriguez Abreu
 *@version 0.1
 *@since Octubre 6, 2013
 */

public class Main{

    /**
     * Imprime el mensaje de uso del programa.
     */
    public static void mensajeUso(){
	System.out.println("Para usar este programa se debe invocar de la siguiente manera: \n"
			   + "java Main <archivo> \n" 
			   + "Donde <archivo> es el archivo que debe contener las cartas.");
    }

    /**
     * Imprime el formato en el que debe de estar el documento a leer.
     */
    public static void mensajeError(){
	System.out.println("El formato del texto es incorrecto,"
			   +" favor de darlo de la siguiente manera:");
	System.out.println("Si es una carta tipo Tierra: \"T; <Nombre>; <Edición>; "
			   + "<Color>; <Número de carta>; <Costo genérico>; <Costo color>\"");
	System.out.println("Si es una carta tipo Hechizo: \"H; <Nombre>; <Edición>; "
			   + "<Color>; <Número de carta>; <Costo genérico>; "
			   + "<Costo color>; <Efecto>; <Leyenda>\"");
	System.out.println("Si es una carta tipo Criatura: \"C; <Nombre>; <Edición>; "
			   + "<Color>; <Número de carta>; <Costo genérico>; "
			   + "<Costo color>; <Ataque>; <Defensa>; <Efecto>; <Leyenda>; <Tipo>\"");
	System.out.println("Sin los \"\".");
    }
    
    public static void main(String[] args)
	throws IOException{
	try {
	    BufferedReader tarjeta = new BufferedReader (new FileReader(args[0])); //Lee el archivo de entrada.
	    //BufferedReader tarjeta = new BufferedReader (new FileReader("tarjetasMagic.txt")); //Otra forma de leer el archivo.
	    Scanner dato = new Scanner(tarjeta).useDelimiter(";");
	    LinkedList<String> deck = new LinkedList<String>();
	    int i;
	    String r = tarjeta.readLine();
	 
	    do{
		String[] arreglotarjeta;
		arreglotarjeta = r.split(";");
	
		for(int k = 0 ; k < arreglotarjeta.length ; k++){
		    deck.add(k, arreglotarjeta[k]);
		    if((deck.get(k)).equalsIgnoreCase("T") || (deck.get(k)).equalsIgnoreCase("H")
		       || (deck.get(k)).equalsIgnoreCase("C") || deck.get(k) == null){
			deck.set(k, "Sin datos");
		    }
		    
		}
		
		
		switch(arreglotarjeta[0]){ //Busca los casos, crea las tarjetas y las imprime en pantalla.
		    
		case "T":
		    if(arreglotarjeta.length >= 6){ 
			System.out.println("T");
			Tierra cartat = new Tierra(arreglotarjeta[1], 
						   arreglotarjeta[2],
						   arreglotarjeta[3], 
						   Integer.parseInt(arreglotarjeta[4]),
						   Integer.parseInt(arreglotarjeta[5]), 
						   Integer.parseInt(arreglotarjeta[6]));
			System.out.println(cartat.toString()); 
		    }else{
			System.out.println("El formato de esta tarjeta Tierra es incorrecto");
		    }	
		    break;	
		    
		case "H":
		    if(arreglotarjeta.length >= 8){	
			System.out.println("H");
			Hechizo cartah = new Hechizo(arreglotarjeta[1],
						     arreglotarjeta[2],
						     arreglotarjeta[3],
						     Integer.parseInt(arreglotarjeta[4]),
						     Integer.parseInt(arreglotarjeta[5]),
						     Integer.parseInt(arreglotarjeta[6]),
						     deck.get(7),
						     deck.get(8));
			System.out.println(cartah.toString());
		    }else{
			System.out.println("El formato de esta tarjeta Hechizo es incorrecto");
		    }		    
		    break;
		    
		case "C":
		    if(arreglotarjeta.length >= 11){
			System.out.println("C");
			Criatura cartac = new Criatura(arreglotarjeta[1],
						       arreglotarjeta[2],
						       arreglotarjeta[3],
						       Integer.parseInt(arreglotarjeta[4]),
						       Integer.parseInt(arreglotarjeta[5]),
						       Integer.parseInt(arreglotarjeta[6]),
						       Integer.parseInt(arreglotarjeta[7]),
						       Integer.parseInt(arreglotarjeta[8]),
						       deck.get(9),
						       deck.get(10),
						       deck.get(11));
			System.out.println(cartac.toString());
		    }
		    else{
			System.out.println("El formato de esta tarjeta Criatura es incorrecto");
		    }
		    break;
		    
		default: 
		    System.out.println("Esta no es una carta.");
		}
		
	    } while((r =tarjeta.readLine()) != null);	 	
	} 
	
	catch (ArrayIndexOutOfBoundsException e){
	    mensajeUso();
	}
	
	catch (NumberFormatException e){
	    mensajeError();	  
	} 
	
	catch (IOException e){
	    System.out.println("El archivo no fue encontrado.");
	    mensajeUso();	    	    	    
	}
	
	catch (NullPointerException e){
	    mensajeError();
	} 
    }
} //Fin de Main.java
